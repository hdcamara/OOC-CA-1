/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooc.enums;

/**
 * THIS IS SOME LEGACY CODE THAT IS PART OF THE SYSTEM AND YOU HAVE TO USE IT.
 * This enum models all the possible makes that a car could be.
 * 
 */
public enum Make {
    
    TOYOTA, 
    FIAT,
    BMW,
    CHEVROLET,
    FORD;
    
}
